

#pragma once

#include "GameFramework/PlayerController.h"
#include "TTTPlayerController.generated.h"

UCLASS()
class TTT_API ATTTPlayerController : public APlayerController
{
	GENERATED_BODY()

	ATTTPlayerController();
	
};
