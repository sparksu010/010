

#include "TTT.h"
#include "TTTPlayerController.h"


ATTTPlayerController::ATTTPlayerController()
{
	bShowMouseCursor = true;
	bEnableClickEvents = true;
}
