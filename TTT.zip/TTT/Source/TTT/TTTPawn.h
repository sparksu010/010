

#pragma once

#include "GameFramework/Pawn.h"
#include "TTTPlayerInterface.h"
#include "TTTPawn.generated.h"

UCLASS()
class TTT_API ATTTPawn : public APawn, public TTTPlayerInterface
{
	GENERATED_BODY()

public:

	UCameraComponent* Camera;

	ATTTPawn();

	virtual void BeginPlay() override;
	
	virtual void Tick( float DeltaSeconds ) override;

	virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;

	virtual void OnTurn() override;
	virtual void OnWin() override;
	virtual void OnLose() override;

	UFUNCTION()
	void OnClick();
	
};
