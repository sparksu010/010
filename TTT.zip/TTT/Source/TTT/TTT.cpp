

#include "TTT.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TTT, "TTT" );
